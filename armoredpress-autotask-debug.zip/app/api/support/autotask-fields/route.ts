export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

import { NextResponse } from 'next/server';
import { withAuth } from '@/lib/auth/middleware';

export const GET = withAuth(async () => {
  const username = process.env.AUTOTASK_API_USERNAME;
  const integrationCode = process.env.AUTOTASK_API_INTEGRATION_CODE;
  const secret = process.env.AUTOTASK_API_SECRET;

  if (!username || !integrationCode || !secret) {
    return NextResponse.json({ ok: false, error: 'Autotask credentials not set' }, { status: 503 });
  }

  // Step 1: zone discovery — return raw response so we can see what URL format Autotask sends
  const zoneRes  = await fetch(
    `https://webservices.autotask.net/atservicesrest/v1.0/zoneInformation?user=${encodeURIComponent(username)}`
  );
  const zoneData = await zoneRes.json();

  // Step 2: try the fields endpoint using the URL from zone discovery
  const baseUrl = (zoneData.url ?? zoneData.webUrl ?? zoneData.zoneUrl ?? '').replace(/\/+$/, '');

  let fieldsData: unknown = null;
  let fieldsError: string | null = null;

  if (baseUrl) {
    const fieldsUrl = `${baseUrl}/Tickets/entityInformation/fields`;
    console.log('[Autotask] Trying fields URL:', fieldsUrl);

    const fieldsRes = await fetch(fieldsUrl, {
      headers: {
        'ApiIntegrationCode': integrationCode,
        'UserName':           username,
        'Secret':             secret,
        'Content-Type':       'application/json',
      },
    });
    fieldsData  = await fieldsRes.json().catch(() => null);
    fieldsError = fieldsRes.ok ? null : `${fieldsRes.status} ${fieldsRes.statusText}`;
  }

  return NextResponse.json({
    ok: true,
    debug: {
      zone_response:  zoneData,
      base_url_used:  baseUrl,
      fields_error:   fieldsError,
      fields_preview: fieldsData,
    },
  });
}, ['internal_admin']);
