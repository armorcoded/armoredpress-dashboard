import { Pool, QueryResult, QueryResultRow } from 'pg';

// Pool is initialised lazily on first use so Next.js can import
// this module during the build phase without DATABASE_URL being present.
let _pool: Pool | null = null;

function getPool(): Pool {
  if (_pool) return _pool;

  if (!process.env.DATABASE_URL) {
    throw new Error('DATABASE_URL environment variable is required');
  }

  _pool = new Pool({
    connectionString: process.env.DATABASE_URL,
    max: 20,
    idleTimeoutMillis: 30_000,
    connectionTimeoutMillis: 5_000,
    ssl: process.env.NODE_ENV === 'production'
      ? { rejectUnauthorized: false }
      : false,
  });

  _pool.on('error', (err) => {
    console.error('[DB] Unexpected pool error:', err);
  });

  return _pool;
}

/**
 * Execute a parameterised query.
 * Always use parameterised queries — never string-interpolate user input.
 *
 * @example
 * const { rows } = await query('SELECT * FROM users WHERE id = $1', [userId]);
 */
export async function query<T extends QueryResultRow = QueryResultRow>(
  text: string,
  params?: unknown[],
): Promise<QueryResult<T>> {
  const pool = getPool();
  const start = Date.now();
  const result = await pool.query<T>(text, params);
  const duration = Date.now() - start;

  if (process.env.NODE_ENV === 'development') {
    console.log('[DB]', { text, duration, rows: result.rowCount });
  }

  return result;
}

/**
 * Explicit type for a query function — avoids the circular
 * `typeof query` self-reference that stricter TypeScript rejects.
 */
export type QueryFn = <T extends QueryResultRow = QueryResultRow>(
  text: string,
  params?: unknown[],
) => Promise<QueryResult<T>>;

/**
 * Run multiple queries in a single transaction.
 * If any query throws, the transaction is rolled back.
 *
 * @example
 * await transaction(async (q) => {
 *   await q('INSERT INTO orgs ...', [...]);
 *   await q('INSERT INTO users ...', [...]);
 * });
 */
export async function transaction<T>(
  fn: (query: QueryFn) => Promise<T>,
): Promise<T> {
  const pool = getPool();
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const boundQuery: QueryFn = <R extends QueryResultRow = QueryResultRow>(
      text: string,
      params?: unknown[],
    ) => client.query<R>(text, params);

    const result = await fn(boundQuery);
    await client.query('COMMIT');
    return result;
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}

export { getPool };
