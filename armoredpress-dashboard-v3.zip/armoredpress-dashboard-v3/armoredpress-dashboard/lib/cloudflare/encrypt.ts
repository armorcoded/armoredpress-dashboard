/**
 * AES-256-GCM encryption for customer Cloudflare API tokens.
 *
 * Tokens are encrypted before being stored in the database and
 * decrypted immediately before use. The key never leaves the server.
 *
 * Key source: CF_TOKEN_ENCRYPTION_KEY env var (32-byte hex string).
 * Generate: openssl rand -hex 32
 */

import crypto from 'crypto';

const ALGORITHM = 'aes-256-gcm';
const KEY_HEX   = process.env.CF_TOKEN_ENCRYPTION_KEY!;

if (!KEY_HEX) {
  throw new Error('CF_TOKEN_ENCRYPTION_KEY must be set (openssl rand -hex 32)');
}

const KEY = Buffer.from(KEY_HEX, 'hex');

if (KEY.length !== 32) {
  throw new Error('CF_TOKEN_ENCRYPTION_KEY must be a 32-byte (64 hex char) value');
}

/**
 * Encrypt a plaintext Cloudflare token.
 * Returns a base64-encoded string: iv:authTag:ciphertext
 */
export function encryptToken(plaintext: string): string {
  const iv         = crypto.randomBytes(12); // 96-bit IV for GCM
  const cipher     = crypto.createCipheriv(ALGORITHM, KEY, iv);
  const ciphertext = Buffer.concat([cipher.update(plaintext, 'utf8'), cipher.final()]);
  const authTag    = cipher.getAuthTag();

  return [
    iv.toString('base64'),
    authTag.toString('base64'),
    ciphertext.toString('base64'),
  ].join(':');
}

/**
 * Decrypt a stored token back to plaintext.
 * Throws if the ciphertext has been tampered with (GCM auth tag mismatch).
 */
export function decryptToken(stored: string): string {
  const [ivB64, authTagB64, ciphertextB64] = stored.split(':');

  if (!ivB64 || !authTagB64 || !ciphertextB64) {
    throw new Error('Invalid encrypted token format');
  }

  const iv         = Buffer.from(ivB64, 'base64');
  const authTag    = Buffer.from(authTagB64, 'base64');
  const ciphertext = Buffer.from(ciphertextB64, 'base64');

  const decipher = crypto.createDecipheriv(ALGORITHM, KEY, iv);
  decipher.setAuthTag(authTag);

  return Buffer.concat([decipher.update(ciphertext), decipher.final()]).toString('utf8');
}
