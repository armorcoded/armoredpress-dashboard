import jwt from 'jsonwebtoken';
import crypto from 'crypto';
import { query } from '@/lib/db/pool';
import type { SessionPayload, User } from '@/types';

const ACCESS_SECRET  = process.env.JWT_ACCESS_SECRET!;
const REFRESH_SECRET = process.env.JWT_REFRESH_SECRET!;
const ACCESS_TTL     = '15m';
const REFRESH_TTL_S  = 60 * 60 * 24 * 7; // 7 days in seconds

if (!ACCESS_SECRET || !REFRESH_SECRET) {
  throw new Error('JWT_ACCESS_SECRET and JWT_REFRESH_SECRET must be set');
}

// ── Access token ─────────────────────────────────────────────────────────────

export function signAccessToken(user: Pick<User, 'id' | 'email' | 'role' | 'org_id'>): string {
  return jwt.sign(
    {
      sub:    user.id,
      email:  user.email,
      role:   user.role,
      org_id: user.org_id,
    },
    ACCESS_SECRET,
    { expiresIn: ACCESS_TTL, algorithm: 'HS256' },
  );
}

export function verifyAccessToken(token: string): SessionPayload {
  return jwt.verify(token, ACCESS_SECRET) as SessionPayload;
}

// ── Refresh token ─────────────────────────────────────────────────────────────

export function generateRefreshToken(): string {
  return crypto.randomBytes(48).toString('hex');
}

export async function storeRefreshToken(userId: string, token: string): Promise<void> {
  const hash      = crypto.createHash('sha256').update(token).digest('hex');
  const expiresAt = new Date(Date.now() + REFRESH_TTL_S * 1000);

  await query(
    `INSERT INTO refresh_tokens (user_id, token_hash, expires_at)
     VALUES ($1, $2, $3)`,
    [userId, hash, expiresAt],
  );
}

export async function rotateRefreshToken(
  oldToken: string,
  userId: string,
): Promise<string | null> {
  const oldHash = crypto.createHash('sha256').update(oldToken).digest('hex');

  // Atomically delete old token and verify it belonged to this user.
  const { rowCount } = await query(
    `DELETE FROM refresh_tokens
     WHERE token_hash = $1 AND user_id = $2 AND expires_at > NOW()`,
    [oldHash, userId],
  );

  if (!rowCount || rowCount === 0) return null; // invalid or expired

  const newToken = generateRefreshToken();
  await storeRefreshToken(userId, newToken);
  return newToken;
}

export async function revokeAllRefreshTokens(userId: string): Promise<void> {
  await query('DELETE FROM refresh_tokens WHERE user_id = $1', [userId]);
}
