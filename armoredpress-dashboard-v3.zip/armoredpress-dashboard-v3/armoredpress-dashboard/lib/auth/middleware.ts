import { NextRequest, NextResponse } from 'next/server';
import { verifyAccessToken } from '@/lib/auth/jwt';
import type { Role, SessionPayload } from '@/types';

export type AuthedRequest = NextRequest & { session: SessionPayload };

type RouteHandler = (req: AuthedRequest, ctx: { params: Record<string, string> }) => Promise<NextResponse>;

/**
 * Wrap an API route handler with JWT authentication.
 * Optionally restrict to one or more roles.
 *
 * @example
 * export const GET = withAuth(async (req) => {
 *   return NextResponse.json({ ok: true, data: req.session });
 * }, ['internal_admin']);
 */
export function withAuth(handler: RouteHandler, allowedRoles?: Role[]) {
  return async (req: NextRequest, ctx: { params: Record<string, string> }) => {
    const token = extractToken(req);

    if (!token) {
      return json({ ok: false, error: 'Unauthenticated.', code: 'NO_TOKEN' }, 401);
    }

    let session: SessionPayload;
    try {
      session = verifyAccessToken(token);
    } catch {
      return json({ ok: false, error: 'Invalid or expired token.', code: 'INVALID_TOKEN' }, 401);
    }

    if (allowedRoles && !allowedRoles.includes(session.role)) {
      return json({ ok: false, error: 'Insufficient permissions.', code: 'FORBIDDEN' }, 403);
    }

    // Attach session to request.
    (req as AuthedRequest).session = session;
    return handler(req as AuthedRequest, ctx);
  };
}

/**
 * Restrict a route to a specific org.
 * internal_admin passes unconditionally.
 * org_admin / org_user must be in the same org as the resource.
 */
export function assertOrgAccess(session: SessionPayload, orgId: string): boolean {
  if (session.role === 'internal_admin') return true;
  return session.org_id === orgId;
}

function extractToken(req: NextRequest): string | null {
  // Prefer Authorization header.
  const auth = req.headers.get('authorization');
  if (auth?.startsWith('Bearer ')) {
    return auth.slice(7);
  }
  // Fallback: httpOnly cookie (set by login route).
  return req.cookies.get('ap_access_token')?.value ?? null;
}

function json(body: object, status: number) {
  return NextResponse.json(body, { status });
}
