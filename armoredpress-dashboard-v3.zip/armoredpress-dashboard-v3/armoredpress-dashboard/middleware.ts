import { NextRequest, NextResponse } from 'next/server';
import { verifyAccessToken } from '@/lib/auth/jwt';

// Routes that don't require authentication.
const PUBLIC_PATHS = [
  '/login',
  '/api/auth/login',
  '/api/auth/verify-totp',
  '/api/auth/refresh',
  '/api/health',
];

export function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;

  // Allow public paths through unconditionally.
  if (PUBLIC_PATHS.some(p => pathname.startsWith(p))) {
    return NextResponse.next();
  }

  // Allow Next.js internals.
  if (pathname.startsWith('/_next') || pathname.startsWith('/favicon')) {
    return NextResponse.next();
  }

  const token = req.cookies.get('ap_access_token')?.value
    ?? req.headers.get('authorization')?.slice(7);

  if (!token) {
    return redirectToLogin(req);
  }

  try {
    const session = verifyAccessToken(token);

    // Partial 2FA tokens must complete TOTP before accessing anything.
    if (String(session.role).startsWith('pending_2fa:')) {
      if (!pathname.startsWith('/login/verify-totp')) {
        return NextResponse.redirect(new URL('/login/verify-totp', req.url));
      }
    }

    return NextResponse.next();
  } catch {
    return redirectToLogin(req);
  }
}

function redirectToLogin(req: NextRequest) {
  // API routes get 401, page routes get redirect.
  if (req.nextUrl.pathname.startsWith('/api/')) {
    return NextResponse.json(
      { ok: false, error: 'Unauthenticated.', code: 'NO_TOKEN' },
      { status: 401 },
    );
  }
  const loginUrl = new URL('/login', req.url);
  loginUrl.searchParams.set('from', req.nextUrl.pathname);
  return NextResponse.redirect(loginUrl);
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico).*)'],
};
