import type { Config } from 'tailwindcss';

const config: Config = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        // ArmoredPress brand — muted blue, corporate
        brand: {
          50:  '#EFF4FB',
          100: '#DDEAF7',
          200: '#B8D0EE',
          300: '#8EB1E3',
          400: '#5B8DD4',
          500: '#3B6DC2',  // primary action
          600: '#2D54A0',
          700: '#234080',
          800: '#1A2F5F',
          900: '#111F3F',
        },
        // Neutral grays
        slate: {
          50:  '#F8FAFC',
          100: '#F1F5F9',
          200: '#E2E8F0',
          300: '#CBD5E1',
          400: '#94A3B8',
          500: '#64748B',
          600: '#475569',
          700: '#334155',
          800: '#1E293B',
          900: '#0F172A',
        },
        // Semantic
        success: { light: '#DCFCE7', DEFAULT: '#16A34A', dark: '#14532D' },
        warning: { light: '#FEF9C3', DEFAULT: '#CA8A04', dark: '#713F12' },
        danger:  { light: '#FEE2E2', DEFAULT: '#DC2626', dark: '#7F1D1D' },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        mono: ['JetBrains Mono', 'Menlo', 'monospace'],
      },
      borderRadius: {
        sm:  '4px',
        md:  '6px',
        lg:  '8px',
        xl:  '12px',
        '2xl': '16px',
      },
      boxShadow: {
        card: '0 1px 3px 0 rgb(0 0 0 / 0.08), 0 1px 2px -1px rgb(0 0 0 / 0.06)',
        'card-hover': '0 4px 6px -1px rgb(0 0 0 / 0.08), 0 2px 4px -2px rgb(0 0 0 / 0.06)',
        input: '0 0 0 3px rgb(59 109 194 / 0.12)',
      },
    },
  },
  plugins: [],
};

export default config;
