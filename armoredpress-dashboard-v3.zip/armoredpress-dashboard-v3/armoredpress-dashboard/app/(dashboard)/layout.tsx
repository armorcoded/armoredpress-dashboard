import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import { verifyAccessToken } from '@/lib/auth/jwt';
import { DashboardShell } from '@/components/layout/shell';

export default async function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const cookieStore = await cookies();
  const token = cookieStore.get('ap_access_token')?.value;

  if (!token) redirect('/login');

  let session: ReturnType<typeof verifyAccessToken>;
  try {
    session = verifyAccessToken(token);
  } catch {
    redirect('/login');
  }

  const initials = session.email.slice(0, 2).toUpperCase();

  return (
    <DashboardShell
      user={{
        email:    session.email,
        role:     session.role,
        initials,
      }}
    >
      {children}
    </DashboardShell>
  );
}
