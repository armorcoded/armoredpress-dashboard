export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

import { NextResponse } from 'next/server';
import { withAuth } from '@/lib/auth/middleware';
import { getTicketFieldInfo } from '@/lib/autotask/client';

/**
 * GET /api/support/autotask-fields
 *
 * Internal helper — internal_admin only.
 * Returns the full field info for the Ticket entity including all
 * picklist values. Use this to find the numeric IDs for:
 *   - issueType  → look for "Hosting"
 *   - subIssueType → look for WordPress, DNS, SSL, etc.
 *   - source → look for your source name
 *
 * Then set the values in .env:
 *   AUTOTASK_ISSUE_TYPE_ID=<id>
 *   AUTOTASK_SUB_WORDPRESS=<id>
 *   etc.
 */
export const GET = withAuth(async () => {
  try {
    const fields = await getTicketFieldInfo();
    return NextResponse.json({ ok: true, data: fields });
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Failed to fetch field info';
    return NextResponse.json({ ok: false, error: msg }, { status: 502 });
  }
}, ['internal_admin']);
